use crate::scene::ChunkAccess;
use crate::{
    algo::{DEFAULT_COLLISION_PARALLEL_CUTOFF, find_collision_pairs},
    scene::PhysicsScene,
};
use marten::Real;
use rapier3d::dynamics::RigidBody;
use rapier3d::geometry::Aabb;
use rapier3d::glamx::{DVec3, IVec3};
use rapier3d::math::Vec3;
use rapier3d::prelude::RigidBodyVelocity;

/// Computes buoyancy
pub fn compute_buoyancy(scene: &PhysicsScene) {
    let physics_state = crate::get_physics_state();
    let collider_map = &physics_state.voxel_collider_map;
    let sable_data = scene.sable_data.read().unwrap_or_else(std::sync::PoisonError::into_inner);
    let mut sim_data = scene.sim_data.write().unwrap_or_else(std::sync::PoisonError::into_inner);

    let Some(body_ids) = sable_data.bodies_by_chart.get(&scene.chart) else {
        return;
    };
    for id in body_ids {
        let Some(body_handle) = sable_data.rigid_bodies.get(id) else {
            continue;
        };
        let info = sable_data.level_colliders.get(id);

        if info.is_none() {
            continue;
        }
        let info = info.unwrap();
        // `bodies_by_chart` makes this a chart-local iteration rather than a global
        // scan performed once for every loaded dimension.
        let Some(body) = sim_data.rigid_body_set.get_mut(*body_handle) else {
            panic!("No body with given handle!");
        };

        let Some(center_of_mass) = info.center_of_mass else {
            panic!("No center of mass for body!");
        };

        let Some(local_bounds_min) = info.local_bounds_min else {
            panic!("No local bounds for body!");
        };
        let Some(local_bounds_max) = info.local_bounds_max else {
            panic!("No local bounds for body!");
        };
        body.reset_forces(false);
        body.reset_torques(false);
        let pairs = find_collision_pairs(
            info,
            None,
            body.position(),
            0.0,
            DEFAULT_COLLISION_PARALLEL_CUTOFF,
            true,
            &sable_data,
            info.environment_chart.unwrap_or(info.chart),
        );
        let vels: RigidBodyVelocity<Real> = *body.vels();

        let complex = (local_bounds_max - local_bounds_min).element_sum() < 10;
        for (static_pos, dynamic_pos) in pairs.iter() {
            let local_pos = dynamic_pos.as_dvec3() + 0.5;
            let local_pos = (local_pos - center_of_mass).as_vec3();

            if complex {
                for i in 0..8 {
                    let x = (i & 1) * 2 - 1;
                    let y = ((i >> 1) & 1) * 2 - 1;
                    let z = ((i >> 2) & 1) * 2 - 1;
                    let local_pos = Vec3::new(
                        local_pos.x + x as Real * 0.25,
                        local_pos.y + y as Real * 0.25,
                        local_pos.z + z as Real * 0.25,
                    );
                    do_drag(body, &vels, static_pos, &local_pos, 0.25, 1.0);
                }
            } else {
                do_drag(body, &vels, static_pos, &local_pos, 0.5, 1.0);
            }
        }
        for (static_pos, dynamic_pos) in pairs.iter() {
            // Atlas: the body's sections live in its chart's chunk map.
            let chunk = sable_data.chart(info.chart).and_then(|c| {
                c.get_chunk(dynamic_pos.x >> 4, dynamic_pos.y >> 4, dynamic_pos.z >> 4)
            });

            if chunk.is_none() {
                continue;
            }

            let (block_id, _voxel_collider_state) = chunk.unwrap().get_block(
                dynamic_pos.x & 15,
                dynamic_pos.y & 15,
                dynamic_pos.z & 15,
            );

            // block id's are unsigned, and offset by 1 to allow for a single "empty" at 0
            if block_id == 0 {
                continue;
            }

            let voxel_collider_data =
                &collider_map.get((block_id - 1) as usize, dynamic_pos.clone());

            let Some(voxel_collider_data) = &voxel_collider_data else {
                continue;
            };

            let local_pos = DVec3::new(
                dynamic_pos.x as f64 + 0.5,
                dynamic_pos.y as f64 + 0.5,
                dynamic_pos.z as f64 + 0.5,
            );
            let local_pos = Vec3::new(
                (local_pos.x - center_of_mass.x) as Real,
                (local_pos.y - center_of_mass.y) as Real,
                (local_pos.z - center_of_mass.z) as Real,
            );
            let complex = (local_bounds_max - local_bounds_min).element_sum() < 10;
            if complex {
                for i in 0..8 {
                    let x = (i & 1) * 2 - 1;
                    let y = ((i >> 1) & 1) * 2 - 1;
                    let z = ((i >> 2) & 1) * 2 - 1;
                    let local_pos = Vec3::new(
                        local_pos.x + x as Real * 0.25,
                        local_pos.y + y as Real * 0.25,
                        local_pos.z + z as Real * 0.25,
                    );
                    do_float(
                        body,
                        static_pos,
                        &local_pos,
                        0.25,
                        voxel_collider_data.volume,
                    );
                }
            } else {
                do_float(
                    body,
                    static_pos,
                    &local_pos,
                    0.5,
                    voxel_collider_data.volume,
                );
            }
        }
    }
}

fn do_drag(
    body: &mut RigidBody,
    vels: &RigidBodyVelocity<Real>,
    static_pos: &IVec3,
    point: &Vec3,
    size: Real,
    strength: Real,
) {
    let point = body.position().transform_point(*point);

    let overlap = Aabb::new(point - size, point + size)
        .intersection(&Aabb::new(static_pos.as_vec3(), static_pos.as_vec3() + 1.0));

    if overlap.is_none() {
        return;
    }

    let volume = overlap.unwrap().volume();
    let velo = vels.velocity_at_point(point, body.mass_properties().world_com);

    body.add_force_at_point(-velo * 1.7 * volume * strength, point, false);
}

fn do_float(body: &mut RigidBody, static_pos: &IVec3, point: &Vec3, size: Real, strength: Real) {
    let point = body.position().transform_point(*point);

    let overlap =
        Aabb::new(point - Vec3::splat(size), point + Vec3::splat(size)).intersection(&Aabb::new(
            Vec3::new(
                static_pos.x as Real,
                static_pos.y as Real,
                static_pos.z as Real,
            ),
            Vec3::new(
                static_pos.x as Real + 1.0,
                static_pos.y as Real + 1.0,
                static_pos.z as Real + 1.0,
            ),
        ));

    if overlap.is_none() {
        return;
    }

    let volume = overlap.unwrap().volume();

    body.add_force_at_point(Vec3::new(0.0, 10.5 * volume * strength, 0.0), point, false);
}

#[cfg(test)]
mod compatibility_regressions {
    use super::*;
    use rapier3d::dynamics::RigidBodyBuilder;

    #[test]
    fn submerged_volume_pushes_up_and_disjoint_water_does_not() {
        let mut body = RigidBodyBuilder::dynamic().translation(Vec3::splat(0.5)).build();
        do_float(&mut body, &IVec3::ZERO, &Vec3::ZERO, 0.5, 1.0);
        assert!((body.user_force().y - 10.5).abs() < 1e-5);
        body.reset_forces(false);
        do_float(&mut body, &IVec3::splat(10), &Vec3::ZERO, 0.5, 1.0);
        assert_eq!(body.user_force(), Vec3::ZERO);
    }
}
