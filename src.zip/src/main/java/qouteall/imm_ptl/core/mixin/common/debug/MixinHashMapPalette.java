package qouteall.imm_ptl.core.mixin.common.debug;

import net.minecraft.core.IdMap;
import net.minecraft.world.level.chunk.HashMapPalette;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(HashMapPalette.class)
public class MixinHashMapPalette<T> {
    // reveal the issue early to help debugging
    @Redirect(
        method = "write",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/core/IdMap;getId(Ljava/lang/Object;)I"
        )
    )
    private int onGetId(IdMap<T> idMap, T object) {
        int id = idMap.getId(object);
        if (id == -1) {
            throw new RuntimeException(
                "(Note: ImmPtl is just doing checking to help debugging) Cannot find intId for %s. Something is wrong with registries.".formatted(object)
            );
        }
        return id;
    }
}
